package Leon_DaTrindade_JesusDavid_ED05_tarea;

/**
 * Mostrar� todos los productos de la campa�a que se haya asignado por el admiinistrativo
 */
public class Tienda {

	public void mostrarComplementos() {
		throw new UnsupportedOperationException();
	}

	public void mostrarZapatos() {
		throw new UnsupportedOperationException();
	}

	public void mostrarBolsos() {
		throw new UnsupportedOperationException();
	}

}