package Leon_DaTrindade_JesusDavid_ED05_tarea;

/**
 * Almacenaremos la información de la campaña que ponga en vigor el administrativo y que comprobará la tienda antes de mostrar los productos.
 */
public class Campaña {

	private String temporada;

	public String getTemporada() {
		return this.temporada;
	}

	/**
	 * 
	 * @param temporada
	 */
	public void setTemporada(String temporada) {
		this.temporada = temporada;
	}

}